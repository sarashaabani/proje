﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sara
{
    public partial class products : Form
    {
        public products()
        {
            InitializeComponent();
        }
        string id_1;
        private void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                string date = textBox1.Text;
                string producttype = textBox2.Text;
                string productname = textBox3.Text;
                int number = int.Parse(textBox4.Text);
                string gram = textBox5.Text;
                string weight = textBox6.Text;
                string price = textBox7.Text;
                string for0 = textBox8.Text;
                string color = textBox9.Text;
                string length = textBox10.Text;
                string width = textBox11.Text;
                string size = textBox12.Text;
                string shape = textBox13.Text;
                string texture = textBox14.Text;
                string query = "INSERT INTO products (date,producttype,productname,number,gram,weight,price,for0,color,length,width,size,shape,texture)"
                    + " VALUES(N'" + date + "',N'" + producttype + "',N'" + productname + "',N'" + number + "',N'" + gram + "',N'" + weight + "',N'" + price + "',N'" + for0+ "',N'" + color + "',N'" + length + "',N'" + width + "',N'" + size + "',N'" + shape + "',N'" + texture + "')";
                SqlConnection sc = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\source\repos\sara\sara\Database1.mdf;Integrated Security=True");
                sc.Open();
                SqlCommand sqlcommand = new SqlCommand(query, sc);
                int i = sqlcommand.ExecuteNonQuery();
                if (i > 0)
                {
                    MessageBox.Show("ثبت شد");
                    textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = textBox5.Text = textBox6.Text = textBox7.Text = textBox8.Text = textBox9.Text = textBox10.Text = textBox11.Text = textBox12.Text = textBox13.Text = textBox14.Text = "";
                    refresh();
                }
                else
                {
                    MessageBox.Show("ثبت ناموفق");
                }
                sc.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("error!" + ex.Message);
            }
        }
        void refresh()
        {
            comboBox1.Items.Clear();
            string query = "SELECT * FROM products";
            SqlConnection sc = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\source\repos\sara\sara\Database1.mdf;Integrated Security=True");
            sc.Open();
            SqlCommand sqlcommand = new SqlCommand(query, sc);
            SqlDataReader dr = sqlcommand.ExecuteReader();
            while (dr.Read())
            {
                comboBox1.Items.Add(dr["id"] + ":" + dr["producttype"] + "|" + dr["productname"] + "|" +  dr["weight"] + "|"  + dr["number"]);
            }
            sc.Close();
        }

        private void Products_Load(object sender, EventArgs e)
        {
            refresh();
            button2.Enabled = false;
            label17.Enabled = label18.Enabled = label19.Enabled = label20.Enabled = textBox17.Enabled = textBox18.Enabled = textBox19.Enabled = textBox20.Enabled = button6.Enabled =false;
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            string id = comboBox1.SelectedItem.ToString();
            id = id.Substring(0, id.IndexOf(":"));
            string number = comboBox1.SelectedItem.ToString();
            int x = number.Length;
            number = number.Substring(x - 1);
            int y = int.Parse(number);
            if (y > 1)
            {
                y = y - 1;
                string query = "UPDATE products SET number='" + y + "' WHERE id='" + id + "'";
                SqlConnection sc = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\source\repos\sara\sara\Database1.mdf;Integrated Security=True");
                sc.Open();
                SqlCommand sqlcommand = new SqlCommand(query, sc);
                int i = sqlcommand.ExecuteNonQuery();
                if (i > 0)
                {
                    MessageBox.Show("موجودی کم شد"); ;
                    refresh();
                }
                else
                {
                    MessageBox.Show("موجودی ناموفق");
                }
                sc.Close();
            }
            else if (y == 1)
            {
                string query = "DELETE FROM products WHERE id='" + id + "'";
                SqlConnection sc = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\source\repos\sara\sara\Database1.mdf;Integrated Security=True");
                sc.Open();
                SqlCommand sqlcommand = new SqlCommand(query, sc);
                int i = sqlcommand.ExecuteNonQuery();
                if (i > 0)
                {
                    MessageBox.Show("موجودی تمام شد");
                    refresh();
                }
                else
                {
                    MessageBox.Show("موحودی ناموفق");
                }
                sc.Close();
            }
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            button2.Enabled = true;
            label17.Enabled = label18.Enabled = label19.Enabled = label20.Enabled = textBox17.Enabled = textBox18.Enabled = textBox19.Enabled = textBox20.Enabled = button6.Enabled = true;
            string id = comboBox1.SelectedItem.ToString();
            id = id.Substring(0, id.IndexOf(":"));
            id_1 = id;
            string query = "SELECT * FROM products WHERE id='" + id + "'";
            SqlConnection sc = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\source\repos\sara\sara\Database1.mdf;Integrated Security=True");
            sc.Open();
            SqlCommand sqlcommand = new SqlCommand(query, sc);
            SqlDataReader dr = sqlcommand.ExecuteReader();
            dr.Read();
            textBox1.Text = dr["date"].ToString();
            textBox2.Text = dr["producttype"].ToString();
            textBox3.Text = dr["productname"].ToString();
            textBox4.Text = dr["number"].ToString();
            textBox5.Text = dr["gram"].ToString();
            textBox6.Text = dr["weight"].ToString();
            textBox7.Text = dr["price"].ToString();
            textBox8.Text = dr["for0"].ToString();
            textBox9.Text = dr["color"].ToString();
            textBox10.Text = dr["length"].ToString();
            textBox11.Text = dr["width"].ToString();
            textBox12.Text = dr["size"].ToString();
            textBox13.Text = dr["shape"].ToString();
            textBox14.Text = dr["texture"].ToString();
            sc.Close();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            try
            {
                string date = textBox1.Text;
                string producttype = textBox2.Text;
                string productname = textBox3.Text;
                int number = int.Parse(textBox4.Text);
                string gram = textBox5.Text;
                string weight = textBox6.Text;
                string price = textBox7.Text;
                string for0 = textBox8.Text;
                string color = textBox9.Text;
                string length = textBox10.Text;
                string width = textBox11.Text;
                string size = textBox12.Text;
                string shape = textBox13.Text;
                string texture = textBox14.Text;
                string query = "UPDATE products SET date=N'" + date + "',producttype=N'" + producttype + "',productname=N'" + productname + "',number='" + number + "',gram=N'" + gram + "',weight=N'" + weight + "',price=N'" + price + "',for0=N'" + for0 + "',color=N'" + color + "',length=N'" + length + "',width=N'" + width + "',size=N'" + size + "',shape=N'" + shape + "',texture=N'" + texture + "' WHERE id='" + id_1 + "'";
                SqlConnection sc = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\source\repos\sara\sara\Database1.mdf;Integrated Security=True");
                sc.Open();
                SqlCommand sqlcommand = new SqlCommand(query, sc);
                int i = sqlcommand.ExecuteNonQuery();
                if (i > 0)
                {
                    MessageBox.Show("بروزرسانی شد");
                    textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = textBox5.Text = textBox6.Text = textBox7.Text = textBox8.Text = textBox9.Text = textBox10.Text = textBox11.Text = textBox12.Text = textBox13.Text = textBox14.Text = "";
                    textBox17.Text = textBox18.Text = textBox19.Text = textBox20.Text = "";
                    refresh();
                    button1.Enabled = true;
                    button2.Enabled = false;
                    label17.Enabled = label18.Enabled = label19.Enabled = label20.Enabled = textBox17.Enabled = textBox18.Enabled = textBox19.Enabled = textBox20.Enabled = button6.Enabled = false;
                }
                else
                {
                    MessageBox.Show("بروزرسانی ناموفق");
                }
                sc.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("error!" + ex.Message);
            }
        }

        private void Button6_Click(object sender, EventArgs e)
        {
            float a = float.Parse(textBox5.Text);
            float b = float.Parse(textBox6.Text);
            float c = a * b;
            textBox17.Text = c.ToString();
            Double d = c * 0.18;
            textBox18.Text = d.ToString("0");
            Double s = (c + d) * 0.07;
            textBox19.Text = s.ToString("0");
            Double f = (d + s) * 0.1;
            textBox20.Text = f.ToString("0");
            Double g = c + d + s + f;
            textBox7.Text = g.ToString("0");
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            string id = comboBox1.SelectedItem.ToString();
            id = id.Substring(0, id.IndexOf(":"));
            string number1 = comboBox1.SelectedItem.ToString();
            int x = number1.Length;
            number1 = number1.Substring(x - 1);
            int y = int.Parse(number1);
            float z = float.Parse(textBox21.Text);
            int s = int.Parse(textBox15.Text);
            double a = z * s;
            double b = a * 0.18;
            double c = (a + b) * 0.7;
            double d = (b + c) * 0.1;
            double f= a + b + c + d;
            textBox16.Text = (f*y).ToString("0");
        }

        private void Button7_Click(object sender, EventArgs e)
        {
            calculate_price cp = new calculate_price();
            cp.Show();
            this.Close();
        }

        private void Button1_MouseEnter(object sender, EventArgs e)
        {
            button1.BackColor = Color.MistyRose;
        }

        private void Button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.LightPink;
        }

        private void Button2_MouseEnter(object sender, EventArgs e)
        {
            button2.BackColor = Color.MistyRose;
        }

        private void Button2_MouseLeave(object sender, EventArgs e)
        {
            button2.BackColor = Color.LightPink;
        }

        private void Button3_MouseEnter(object sender, EventArgs e)
        {
            button3.BackColor = Color.MistyRose;
        }

        private void Button3_MouseLeave(object sender, EventArgs e)
        {
            button3.BackColor = Color.LightPink;
        }

        private void Button4_MouseEnter(object sender, EventArgs e)
        {
            button4.BackColor = Color.MistyRose;
        }

        private void Button4_MouseLeave(object sender, EventArgs e)
        {
            button4.BackColor = Color.LightPink;
        }

        private void Button5_MouseEnter(object sender, EventArgs e)
        {
            button5.BackColor = Color.MistyRose;
        }

        private void Button5_MouseLeave(object sender, EventArgs e)
        {
            button5.BackColor = Color.LightPink;
        }

        private void Button6_MouseEnter(object sender, EventArgs e)
        {
            button6.BackColor = Color.MistyRose;
        }

        private void Button6_MouseLeave(object sender, EventArgs e)
        {
            button6.BackColor = Color.LightPink;
        }
    }
}
