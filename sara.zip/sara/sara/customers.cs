﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sara
{
    public partial class customers : Form
    {
        public customers()
        {
            InitializeComponent();
        }
        string id_1;
        private void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                string name = textBox1.Text;
                string family = textBox2.Text;
                string phone = textBox3.Text;
                string address = textBox4.Text;
                string email = textBox5.Text;
                string query = "INSERT INTO customers (name,family,phone,address,email)" +
                    " VALUES (N'" + name + "',N'" + family + "',N'" + phone + "',N'" + address + "',N'" + email + "')";
                SqlConnection sc = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\source\repos\sara\sara\Database1.mdf;Integrated Security=True");
                sc.Open();
                SqlCommand sqlcommand = new SqlCommand(query, sc);
                int i = sqlcommand.ExecuteNonQuery();
                if (i > 0)
                {
                    MessageBox.Show("ثبت شد");
                    textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = textBox5.Text = "";
                    refresh();
                }
                else
                {
                    MessageBox.Show("ثبت ناموفق");
                }
                sc.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex.Message);
            }
        }
        void refresh()
        {
            comboBox1.Items.Clear();
            string query = "SELECT * FROM customers";
            SqlConnection sc = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\source\repos\sara\sara\Database1.mdf;Integrated Security=True");
            sc.Open();
            SqlCommand sqlcommand = new SqlCommand(query, sc);
            SqlDataReader dr = sqlcommand.ExecuteReader();
            while (dr.Read())
            {
                comboBox1.Items.Add(dr["id"] + ":" + dr["name"] + " " + dr["family"]);
            }
            sc.Close();
        }

        private void Customers_Load(object sender, EventArgs e)
        {
            refresh();
            button2.Enabled = false;
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            string id = comboBox1.SelectedItem.ToString();
            id = id.Substring(0, id.IndexOf(":"));
            try
            {
                string query = "DELETE FROM customers WHERE id='" + id + "'";
                SqlConnection sc = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\source\repos\sara\sara\Database1.mdf;Integrated Security=True");
                sc.Open();
                SqlCommand sqlcommand = new SqlCommand(query, sc);
                int i = sqlcommand.ExecuteNonQuery();
                if (i > 0)
                {
                    MessageBox.Show("حذف شد");
                    refresh();
                }
                else
                {
                    MessageBox.Show("حذف ناموفق");
                }
                sc.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex.Message);
            }
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            button2.Enabled = true;
            string id = comboBox1.SelectedItem.ToString();
            id = id.Substring(0, id.IndexOf(":"));
            id_1 = id;
            string query = "SELECT * FROM customers WHERE id='" + id + "'";
            SqlConnection sc = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\source\repos\sara\sara\Database1.mdf;Integrated Security=True");
            sc.Open();
            SqlCommand sqlcommand = new SqlCommand(query, sc);
            SqlDataReader dr = sqlcommand.ExecuteReader();
            dr.Read();
            textBox1.Text = dr["name"].ToString();
            textBox2.Text = dr["family"].ToString();
            textBox3.Text = dr["phone"].ToString();
            textBox4.Text = dr["address"].ToString();
            textBox5.Text = dr["email"].ToString();
            sc.Close();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            try
            {
                string name = textBox1.Text;
                string family = textBox2.Text;
                string phone = textBox3.Text;
                string address = textBox4.Text;
                string email = textBox5.Text;
                string query = "UPDATE customers SET name=N'" + name + "',family=N'" + family + "',phone=N'" + phone + "'" +
                    ",address=N'" + address + "',email=N'" + email + "' WHERE id='" + id_1 + "'";
                SqlConnection sc = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\source\repos\sara\sara\Database1.mdf;Integrated Security=True");
                sc.Open();
                SqlCommand sqlcommand = new SqlCommand(query, sc);
                int i = sqlcommand.ExecuteNonQuery();
                if (i > 0)
                {
                    MessageBox.Show("بروزرسانی شد");
                    textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = textBox5.Text = "";
                    refresh();
                    button1.Enabled = true;
                    button2.Enabled = false;
                }
                else
                {
                    MessageBox.Show("بروزرسانی ناموفق");
                }
                sc.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex.Message);
            }
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Close();
        }

        private void Button1_MouseEnter(object sender, EventArgs e)
        {
            button1.BackColor = Color.MistyRose;
        }

        private void Button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.LightPink;
        }

        private void Button2_MouseEnter(object sender, EventArgs e)
        {
            button2.BackColor = Color.MistyRose;
        }

        private void Button2_MouseLeave(object sender, EventArgs e)
        {
            button2.BackColor = Color.LightPink;
        }

        private void Button3_MouseEnter(object sender, EventArgs e)
        {
            button3.BackColor = Color.MistyRose;
        }

        private void Button3_MouseLeave(object sender, EventArgs e)
        {
            button3.BackColor = Color.LightPink;
        }

        private void Button4_MouseEnter(object sender, EventArgs e)
        {
            button4.BackColor = Color.MistyRose;
        }

        private void Button4_MouseLeave(object sender, EventArgs e)
        {
            button4.BackColor = Color.LightPink;
        }
    }
}
