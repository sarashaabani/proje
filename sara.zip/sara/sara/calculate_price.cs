﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sara
{
    public partial class calculate_price : Form
    {
        public calculate_price()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            float a = float.Parse(textBox2.Text);
            float b = float.Parse(textBox3.Text);
            float c = a * b;
            textBox4.Text = c.ToString();
            Double d = c * 0.18;
            textBox5.Text = d.ToString("0");
            Double s = (c + d) * 0.07;
            textBox6.Text = s.ToString("0");
            Double f = (d + s) * 0.1;
            textBox7.Text = f.ToString("0");
            Double g = c + d + s + f;
            textBox8.Text = g.ToString("0");
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            products ps = new products();
            ps.textBox1.Text = textBox1.Text;
            ps.textBox5.Text = textBox2.Text;
            ps.textBox6.Text = textBox3.Text;
            ps.textBox7.Text = textBox8.Text;
            ps.Show();
            textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = textBox5.Text = textBox6.Text = textBox7.Text = textBox8.Text = "";
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Close();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            products ps = new products();
            ps.Show();
            this.Hide();
        }

        private void Button1_MouseEnter(object sender, EventArgs e)
        {
            button1.BackColor = Color.MistyRose;
        }

        private void Button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.LightPink;
        }

        private void Button2_DragEnter(object sender, DragEventArgs e)
        {
            button2.BackColor = Color.MistyRose;
        }

        private void Button2_DragLeave(object sender, EventArgs e)
        {
            button2.BackColor = Color.LightPink;
        }
    }
}
