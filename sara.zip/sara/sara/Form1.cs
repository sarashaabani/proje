﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sara
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_MouseEnter(object sender, EventArgs e)
        {
            button1.BackColor = Color.MistyRose;
        }

        private void Button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.LightPink;
        }

        private void Button2_MouseEnter(object sender, EventArgs e)
        {
            button2.BackColor = Color.MistyRose;
        }

        private void Button2_MouseLeave(object sender, EventArgs e)
        {
            button2.BackColor = Color.LightPink;
        }

        private void Button3_MouseEnter(object sender, EventArgs e)
        {
            button3.BackColor = Color.MistyRose;
        }

        private void Button3_MouseLeave(object sender, EventArgs e)
        {
            button3.BackColor = Color.LightPink;
        }

        private void Button4_MouseEnter(object sender, EventArgs e)
        {
            button4.BackColor = Color.MistyRose;
        }

        private void Button4_MouseLeave(object sender, EventArgs e)
        {
            button4.BackColor = Color.LightPink;
        }
        customers_list cl = new customers_list();
        private void Button1_Click(object sender, EventArgs e)
        {
            cl.Show();
            this.Hide();
        }
        customers cs = new customers();
        private void Button2_Click(object sender, EventArgs e)
        {
            cs.Show();
            this.Hide();
        }
        products_list pl = new products_list();
        private void Button3_Click(object sender, EventArgs e)
        {
            pl.Show();
            this.Hide();
        }
        calculate_price cp= new calculate_price();
        private void Button4_Click(object sender, EventArgs e)
        {
            cp.Show();
            this.Hide();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Windows.Forms.Application.ExitThread();
        }
    }
}
