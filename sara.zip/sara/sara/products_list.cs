﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sara
{
    public partial class products_list : Form
    {
        public products_list()
        {
            InitializeComponent();
        }
        private void ReadFromDatabase()
        {
            SqlConnection sc = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\source\repos\sara\sara\Database1.mdf;Integrated Security=True");
            SqlCommand sqlCommand = new SqlCommand();
            sqlCommand.Connection = sc;
            sqlCommand.CommandText = "select * from products";
            DataTable dataTable = new DataTable();
            SqlDataAdapter sqlDataAdapter= new SqlDataAdapter();
            sqlDataAdapter.SelectCommand = sqlCommand;
            sqlDataAdapter.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
        }
        private void Products_list_Load(object sender, EventArgs e)
        {
            ReadFromDatabase();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Close();
        }
    }
}
